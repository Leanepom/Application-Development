export default [
  {
    id: "1",
    name: "Omelette protéinée",
    image: "https://www.example.com/omelette.jpg",
    calories: 350,
    proteins: 25,
    type: "breakfast",
  },
  {
    id: "2",
    name: "Poulet riz légumes",
    image: "https://www.example.com/chickenrice.jpg",
    calories: 550,
    proteins: 40,
    type: "lunch",
  },
  {
    id: "3",
    name: "Smoothie banane protéine",
    image: "https://www.example.com/smoothie.jpg",
    calories: 250,
    proteins: 18,
    type: "snack",
  },
];
